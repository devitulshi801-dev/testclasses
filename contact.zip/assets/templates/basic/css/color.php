
:root{
--base-h: 210;
--base-s: 100%;
--base-l: 50%;
--base-two-h: 231;
--base-two-s: 48%;
--base-two-l: 47%;
}